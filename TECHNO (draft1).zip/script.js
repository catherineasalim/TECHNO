// ===== DATA =====
const jobs = [
  {
    title: 'Frontend Developer',
    company: 'Astra Digital',
    icon: '⚙️',
    type: 'Full-time',
    location: 'Remote',
    exp: 'Fresh Graduate',
    salary: 'Rp 6–9 Juta',
    urgent: true,
    tags: ['Remote', 'Full-time', 'IT']
  },
  {
    title: 'Data Analyst',
    company: 'Grab Indonesia',
    icon: '🚗',
    type: 'Full-time',
    location: 'Surabaya',
    exp: '0–2 Tahun',
    salary: 'Rp 7–10 Juta',
    urgent: false,
    tags: ['Full-time', 'Business']
  },
  {
    title: 'UI/UX Designer',
    company: 'Tiket.com',
    icon: '✈️',
    type: 'Full-time',
    location: 'Remote',
    exp: 'Fresh Graduate',
    salary: 'Rp 5–8 Juta',
    urgent: true,
    tags: ['Remote', 'Design']
  },
  {
    title: 'Backend Engineer',
    company: 'Bukalapak',
    icon: '🛍️',
    type: 'Internship',
    location: 'Remote',
    exp: 'Mahasiswa/FG',
    salary: 'Rp 3–5 Juta',
    urgent: false,
    tags: ['Internship', 'IT']
  },
  {
    title: 'Business Development',
    company: 'Traveloka',
    icon: '🌏',
    type: 'Full-time',
    location: 'Surabaya',
    exp: '0–1 Tahun',
    salary: 'Rp 5–7 Juta',
    urgent: false,
    tags: ['Full-time', 'Business']
  },
  {
    title: 'Marketing Specialist',
    company: 'Shopee',
    icon: '🛒',
    type: 'Full-time',
    location: 'Surabaya (Hybrid)',
    exp: 'Fresh Graduate',
    salary: 'Rp 5–8 Juta',
    urgent: true,
    tags: ['Full-time', 'Marketing']
  }
];

let activeFilter = 'Semua';
let searchQ = '';

// ===== FILTER =====
function setFilter(filter, el) {
  activeFilter = filter;

  document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
  el.classList.add('active');

  renderJobs();
}

// ===== SEARCH =====
function filterJobs() {
  const input = document.getElementById('jobSearch');
  searchQ = input.value.toLowerCase();
  renderJobs();
}

// ===== RENDER =====
function renderJobs() {
  const grid = document.getElementById('lokerGrid');
  if (!grid) return;

  const filtered = jobs.filter(j => {
    const matchFilter =
      activeFilter === 'Semua' || j.tags.includes(activeFilter);

    const matchSearch =
      j.title.toLowerCase().includes(searchQ) ||
      j.company.toLowerCase().includes(searchQ);

    return matchFilter && matchSearch;
  });

  grid.innerHTML = filtered.map(j => `
    <div class="glass job-card">
      
      <div class="job-card-top">
        <div class="company-logo">${j.icon}</div>
        ${j.urgent ? '<span class="urgent-badge">🔥 Butuh Cepat</span>' : ''}
      </div>

      <h3>${j.title}</h3>
      <div class="company-name">${j.company}</div>

      <div class="job-meta">
        <span class="meta-pill">📍 ${j.location}</span>
        <span class="meta-pill">💼 ${j.type}</span>
        <span class="meta-pill">🎓 ${j.exp}</span>
      </div>

      <div class="salary">${j.salary}</div>

      <button class="apply-btn" onclick="applyJob('${j.title}')">
        Apply →
      </button>

      <button class="bookmark-btn" onclick="saveJob('${j.title}')">
        ⭐ Save
      </button>

    </div>
  `).join('');
}

// ===== SAVE JOB =====
function saveJob(title) {
  let saved = JSON.parse(localStorage.getItem("savedJobs")) || [];

  if (!saved.includes(title)) {
    saved.push(title);
    localStorage.setItem("savedJobs", JSON.stringify(saved));
    alert("Berhasil disimpan!");
  }
}

// ===== APPLY JOB =====
function applyJob(title) {
  let applied = JSON.parse(localStorage.getItem("appliedJobs")) || [];

  if (!applied.includes(title)) {
    applied.push(title);
    localStorage.setItem("appliedJobs", JSON.stringify(applied));
    alert("Berhasil daftar!");
  }
}
function showSaved() {
  const saved = JSON.parse(localStorage.getItem("savedJobs")) || [];

  const filtered = jobs.filter(j => saved.includes(j.title));
  renderCustom(filtered);
}
function showApplied() {
  const applied = JSON.parse(localStorage.getItem("appliedJobs")) || [];

  const filtered = jobs.filter(j => applied.includes(j.title));
  renderCustom(filtered);
}

function renderCustom(data) {
  const grid = document.getElementById('lokerGrid');

  grid.innerHTML = data.map(j => `
    <div class="glass job-card">
      
      <div class="job-card-top">
        <div class="company-logo">${j.icon}</div>
        ${j.urgent ? '<span class="urgent-badge">🔥 Butuh Cepat</span>' : ''}
      </div>

      <h3>${j.title}</h3>
      <div class="company-name">${j.company}</div>

      <div class="job-meta">
        <span class="meta-pill">📍 ${j.location}</span>
        <span class="meta-pill">💼 ${j.type}</span>
        <span class="meta-pill">🎓 ${j.exp}</span>
      </div>

      <div class="salary">${j.salary}</div>

      <button class="apply-btn" onclick="applyJob('${j.title}')">Apply</button>
      <button class="bookmark-btn" onclick="saveJob('${j.title}')">⭐ Save</button>

    </div>
  `).join('');
}

// ===== TAB =====
function switchTab(id, btn) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

  btn.classList.add('active');
  document.getElementById('tab-' + id).classList.add('active');
}

function openModal(name) {
  const modal = document.getElementById('bookModal');
  document.getElementById('modalMentorName').textContent = 'Booking dengan ' + name;
  modal.classList.add('show');
}

function closeModal() {
  document.getElementById('bookModal').classList.remove('show');
}

function selectOpt(el) {
  el.closest('.session-options')
    .querySelectorAll('.session-opt')
    .forEach(o => o.classList.remove('selected'));

  el.classList.add('selected');
}

  // MENTOR DATA
  const mentors = [
    { name: 'Andi Kurniawan', role: 'Product Manager', company: 'Gojek', initials: 'AK', rating: '4.9', reviews: 128, tags: ['Product Strategy', 'CV Review', 'Interview Prep'], price: 'Rp 75.000', color: '#1A3D63' },
    { name: 'Sari Dewi', role: 'Data Scientist', company: 'Tokopedia', initials: 'SD', rating: '4.8', reviews: 89, tags: ['Data Analysis', 'Python', 'Career Path'], price: 'Rp 85.000', color: '#0F4C75' },
    { name: 'Budi Santoso', role: 'Senior Engineer', company: 'Traveloka', initials: 'BS', rating: '5.0', reviews: 202, tags: ['System Design', 'Coding Interview', 'Backend'], price: 'Rp 100.000', color: '#1B262C' },
    { name: 'Maya Putri', role: 'UI/UX Lead', company: 'Shopee', initials: 'MP', rating: '4.9', reviews: 145, tags: ['Portfolio Review', 'Figma', 'Design Career'], price: 'Rp 70.000', color: '#2C3E50' },
    { name: 'Rizky Hakim', role: 'Business Dev Manager', company: 'Grab', initials: 'RH', rating: '4.7', reviews: 67, tags: ['Business Strategy', 'BD Career', 'Networking'], price: 'Rp 65.000', color: '#145A32' },
    { name: 'Ayu Lestari', role: 'HR Business Partner', company: 'Unilever', initials: 'AL', rating: '4.8', reviews: 93, tags: ['HR Career', 'Interview Tips', 'CV Review'], price: 'Rp 60.000', color: '#1A5276' },
  ];

  function renderMentors() {
    const grid = document.getElementById('mentorGrid');
    grid.innerHTML = mentors.map(m => `
      <div class="glass mentor-card">
        <div class="mentor-card-top">
          <div class="avatar" style="background:linear-gradient(135deg,${m.color},#0A1931)">${m.initials}</div>
          <div>
            <h3>${m.name}</h3>
            <div class="role">${m.role}</div>
            <div class="company">${m.company}</div>
          </div>
        </div>
        <div class="mentor-stars"><span style="color:#F0C040; font-size:13px;">${'★'.repeat(5)}</span><span style="font-size:12px; color:var(--text-muted); margin-left:6px;">${m.rating} (${m.reviews} review)</span></div>
        <div class="mentor-tags">${m.tags.map(t => `<span class="tag">${t}</span>`).join('')}</div>
        <div class="mentor-price">${m.price} <span>/ sesi</span></div>
        <button class="book-btn" onclick="openModal('${m.name}')">Book Sesi →</button>
      </div>
    `).join('');
  }

// ===== REGISTER MODAL =====
function openRegisterModal() {
  document.getElementById("registerModal").classList.add("show");
}

function closeRegister() {
  document.getElementById("registerModal").classList.remove("show");
}

// ===== REGISTER USER =====
function registerUser() {
  const user = {
    name: document.getElementById("regName").value,
    birth: document.getElementById("regBirth").value,
    city: document.getElementById("regCity").value,
    email: document.getElementById("regEmail").value,
    social: document.getElementById("regSocial").value,
    linkedin: document.getElementById("regLinkedin").value
  };

  localStorage.setItem("user", JSON.stringify(user));

  initUserUI();
  closeRegister();
}


function initUserUI() {
  const user = JSON.parse(localStorage.getItem("user"));

  if (!user) return;

  document.querySelector(".nav-cta").style.display = "none";

  const profile = document.getElementById("profileMenu");
  profile.classList.remove("hidden");

  document.getElementById("profileInitial").textContent =
    user.name.charAt(0).toUpperCase();
}

document.addEventListener("DOMContentLoaded", () => {
  initUserUI();
});

function toggleDropdown() {
  document.getElementById("dropdownMenu").classList.toggle("hidden");
}

function logout() {
  localStorage.removeItem("user");
  location.reload();
}
  

// ===== INIT =====
document.addEventListener("DOMContentLoaded", () => {
  renderJobs();
  renderMentors();
});